""" 
Programa imprime 5
Definição: esse programa imprime na tela os cinco primeiros números naturais
Autor: Eduardo M
Data: 24/03/2026
Versão: 0.0.1
"""

# Alocação de mémoria

numero_1 = 0
numero_2 = 0
numero_3 = 0
numero_4 = 0
numero_5 = 0
i = 0

# Entrada de dados

# Processamento

# Saída
while i < 5:
    print (i+1)
    i = i + 1